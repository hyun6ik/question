package springeighthproject.spring_jpa.domain;

public enum DeliveryStatus {
    READY, COMP
}
