package springeighthproject.spring_jpa.domain;

public enum OrderStatus {
    ORDER,CANCEL
}
