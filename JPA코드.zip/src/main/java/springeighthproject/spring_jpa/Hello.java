package springeighthproject.spring_jpa;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class Hello {

    private String data;
}
