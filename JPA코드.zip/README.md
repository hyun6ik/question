# Spring-EighthProject
Spring + JPA 복습
