package com.example.shop_using_springdatajpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopUsingSpringdatajpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
