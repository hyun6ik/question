package com.example.shop_using_springdatajpa.domain;

public enum OrderStatus {
    ORDER, CANCEL
}
