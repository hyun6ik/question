package com.example.shop_using_springdatajpa.domain;

public enum DeliveryStatus {
    COMPLETE, READY
}
