package com.example.shop_using_springdatajpa;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class Hello {

    private String data;
}
